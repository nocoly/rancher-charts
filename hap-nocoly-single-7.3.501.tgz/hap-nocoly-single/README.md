# Nocoly HAP Single-Node Helm Chart

This chart deploys Nocoly HAP as a single-node installation from Rancher Apps or Helm.

## Components

| Component | Purpose | Port |
| --- | --- | --- |
| `app` | Main HAP application services | 8880, exposed through NodePort |
| `sc` | MySQL, MongoDB, Redis, Kafka, ZooKeeper, Elasticsearch, MinIO, and file services | Internal |
| `command` | Code execution service | Internal |
| `doc` | Document preview service | Internal |
| `flink` | Data integration; optional with `flink.enabled=false` | 8081 |

## Prerequisites

- Kubernetes 1.23 or later.
- A default or explicitly selected StorageClass, such as `local-path` for single-node RKE2 or k3s.
- Access to the public `nocoly` container images.
- Recommended production capacity: 8 CPU cores, 48 GiB RAM, and SSD storage. Minimum test capacity: 8 CPU cores and 32 GiB RAM.

## Install

In Rancher, open **Apps > Charts**, select **Nocoly HAP Single-Node**, and choose **Install**.

With Helm:

```bash
helm upgrade --install hap-nocoly-single ./hap-nocoly-single \
  --namespace nocoly \
  --create-namespace \
  --set-string hap.addressMain="http://YOUR_HOST:30880" \
  --set-string hap.captainEndpoint="http://CAPTAIN_HOST:38880" \
  --set-string persistence.storageClass="local-path"
```

## Required values

| Value | Description |
| --- | --- |
| `hap.addressMain` | Browser access URL including the port. It must match the URL used to access HAP. |
| `hap.captainEndpoint` | Endpoint of the external Captain service. |
| `persistence.storageClass` | StorageClass used by both persistent volumes. |

## Main values

| Value | Default | Description |
| --- | --- | --- |
| `hap.nodePort` | `30880` | NodePort exposing application port 8880 |
| `hap.apiToken` | Empty | Generates 32 characters on first install and reuses the existing Secret on upgrades; an explicit value supplies or rotates the token |
| `hap.appVersion` | `7.3.5` | HAP application version |
| `flink.enabled` | `true` | Enables Flink data integration |
| `persistence.sharedDataSize` | `30Gi` | Shared data volume mounted at `/data` |
| `persistence.hapDataSize` | `10Gi` | Application data volume mounted at `/data/hap/data` |

## Storage

- `hap-shared-data` is shared by `app`, `sc`, and `flink` and contains databases, object storage, and indexes.
- `hap-data` is mounted by `app` at `/data/hap/data`.
- The chart uses ReadWriteOnce volumes and is intended for a single-node deployment.

## API token

The API token is stored in the `hap-secret` Kubernetes Secret. When `hap.apiToken` is empty, the first installation generates a 32-character alphanumeric token. Upgrades reuse the existing Secret. To rotate the token, run an upgrade with `--set-string hap.apiToken=NEW_VALUE`.

## Access

Open the URL configured in `hap.addressMain` and complete the initial HAP setup.
