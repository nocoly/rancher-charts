# Nocoly HAP Single-Node

Deploy Nocoly HAP as a single-node installation with five components: **app**, **sc**, **command**, **doc**, and optional **flink** data integration.

Before installation:

- Set the main access URL to the exact browser URL, including the port.
- Set the external Captain service endpoint.
- Select the StorageClass and confirm the persistent volume sizes.
- Leave the API token empty to generate a 32-character value, or enter a specific value.

The application is exposed through NodePort `30880` by default.
